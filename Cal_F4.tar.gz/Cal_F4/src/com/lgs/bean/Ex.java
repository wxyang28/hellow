package com.lgs.bean;

public class Ex {
   public String kind;
   public String body;
   public String head;
public String getKind() {
	return kind;
}
public void setKind(String kind) {
	this.kind = kind;
}
public String getBody() {
	return body;
}
public void setBody(String body) {
	this.body = body;
}
public String getHead() {
	return head;
}
public void setHead(String head) {
	this.head = head;
}
   
}
